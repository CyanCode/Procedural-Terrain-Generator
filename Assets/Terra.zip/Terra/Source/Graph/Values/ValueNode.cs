﻿using XNode;

namespace Terra.Graph.Values {
	public abstract class ValueNode: Node {
		public const string MENU_PARENT_NAME = "Value/";
	}
}
