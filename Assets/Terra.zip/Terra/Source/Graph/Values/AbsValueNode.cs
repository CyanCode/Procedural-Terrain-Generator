﻿namespace Terra.Graph.Values {
	internal class AbsValueNode {
		public const string MENU_PARENT_NAME = "Value/";
	}
}
