namespace Terra.CoherentNoise
{
	internal class Constants
	{
		public const int MultiplierX = 1619;
		public const int MultiplierY = 31337;
		public const int MultiplierZ = 6971;
		public const int MultiplierSeed = 1013;
		public const int ValueShift = 8;
	}
}